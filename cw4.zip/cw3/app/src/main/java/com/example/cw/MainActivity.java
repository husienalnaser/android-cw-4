package com.example.cw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.ednum1);
        final EditText y = findViewById(R.id.ednum2);
        Button darb = findViewById(R.id.btnadd2);
        Button div = findViewById(R.id.btnadd3);

        final Button q =findViewById(R.id.btnadd);

        q.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int sum = Integer.parseInt(x.getText().toString()) + Integer.parseInt(y.getText().toString());
//                Toast.makeText(MainActivity.this, sum + "", Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, sum+ "", Toast.LENGTH_SHORT).show();
            }
        });
        darb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int sum = Integer.parseInt(x.getText().toString()) * Integer.parseInt(y.getText().toString());
//                Toast.makeText(MainActivity.this, sum + "", Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, sum+ "", Toast.LENGTH_SHORT).show();
            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int sum = Integer.parseInt(x.getText().toString()) / Integer.parseInt(y.getText().toString());
//                Toast.makeText(MainActivity.this, sum + "", Toast.LENGTH_SHORT).show();
                Toast.makeText(MainActivity.this, sum+ "", Toast.LENGTH_SHORT).show();
            }
        });

    }
}